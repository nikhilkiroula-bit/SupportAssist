---
name: SupportAssist IT Fleet Management
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#404752'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#717783'
  outline-variant: '#c0c7d4'
  surface-tint: '#0060a9'
  primary: '#005da4'
  on-primary: '#ffffff'
  primary-container: '#0076ce'
  on-primary-container: '#fcfbff'
  inverse-primary: '#a2c9ff'
  secondary: '#1261a3'
  on-secondary: '#ffffff'
  secondary-container: '#7ab7ff'
  on-secondary-container: '#00477d'
  tertiary: '#006093'
  on-tertiary: '#ffffff'
  tertiary-container: '#007ab9'
  on-tertiary-container: '#fbfbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d3e4ff'
  primary-fixed-dim: '#a2c9ff'
  on-primary-fixed: '#001c38'
  on-primary-fixed-variant: '#004881'
  secondary-fixed: '#d2e4ff'
  secondary-fixed-dim: '#a1c9ff'
  on-secondary-fixed: '#001c37'
  on-secondary-fixed-variant: '#00487f'
  tertiary-fixed: '#cce5ff'
  tertiary-fixed-dim: '#93ccff'
  on-tertiary-fixed: '#001d31'
  on-tertiary-fixed-variant: '#004b73'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-sm:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.03em
  code-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

This design system targets enterprise IT administrators, systems engineers, and fleet operations directors who oversee hundreds to hundreds of thousands of PC endpoints. The visual style embodies Modern Enterprise Corporate—clean, authoritative, systematic, and engineered for high-density diagnostic comprehension. 

Key principles:
- **Instant Triage (5-Second Rule):** Core system states, fleet-wide health rollups, and urgent remediations must be parseable at a glance via unambiguous color assignments and structured typographic hierarchy.
- **Architectural Precision:** Interfaces favor clean modularity, disciplined alignment, crisp 1px borders, and measured structural whitespace over decorative flourishes.
- **Calibrated Ergonomics:** Balanced density allows high volume data review without cognitive fatigue during extended administrative sessions.

## Colors

The palette leverages authoritative enterprise blues grounded in cool technical slates. 

- **Primary Brand (`#0076CE`):** The primary interaction anchor for primary action buttons, active navigation markers, selection rings, and high-priority linkages.
- **Secondary Brand (`#005A9C`):** Used for pressed states, key interactive headers, and focused enterprise branding elements.
- **Tertiary Brand (`#0284C7`):** Reserved for contextual info alerts, metric progress fills, and passive links.
- **Surfaces & Canvas:** Application canvas defaults to `#F4F6F9`, establishing subtle contrast with pure `#FFFFFF` modular card surfaces. Section dividers and structural card borders use `#E2E8F0`.
- **Text & Hierarchy:** Primary typography uses `#0F172A` (Slate 900) for uncompromised legibility; secondary descriptors utilize `#475569` (Slate 600); disabled/placeholder data uses `#94A3B8` (Slate 400).
- **Strict Semantic Status Engine:**
  - **Critical / Failed:** `#DC2626` (Red 600) with `#FEF2F2` tinted background.
  - **Warning / Degraded / Blocked:** `#D97706` (Amber 600) with `#FFFBEB` tinted background.
  - **Success / Passed / Healthy:** `#16A34A` (Green 600) with `#F0FDF4` tinted background.
  - **Informational / Syncing:** `#0284C7` (Sky 600) with `#F0F9FF` tinted background.

## Typography

The typographic engine uses Inter across all hierarchical roles to provide clean neutral geometry and superior rendering at low pixel densities.

- **System IDs & Telemetry:** For Service Tags, MAC addresses, IP ranges, and BIOS versions, `code-sm` (JetBrains Mono) is paired to prevent visual ambiguity between alphanumeric characters (e.g., `0` vs `O`, `1` vs `l`).
- **Metric Pairings:** Large numeric callouts (e.g., "99.8% Healthy") utilize `display-lg` paired with an uppercase `label-sm` subtitle for instant operational status absorption.
- **Density Tuning:** Body text defaults to `body-md` (14px) for data grids and administrative forms, dropping to `body-sm` (12px) strictly for secondary audit timestamps and table metadata.

## Layout & Spacing

The layout is built on a responsive 12-column fluid grid system paired with an 8px spatial grid unit (with 4px half-steps for compact data components).

- **Desktop Form Factor (1280px and wider):** Fixed 240px or 64px collapsible left administrative navigation sidebar, paired with a fluid main canvas with `margin-lg` (2rem / 32px) margins and `gutter-lg` (1.5rem / 24px) column gutters.
- **Tablet / Small Viewports (768px - 1279px):** Sidebar collapses to an icon rail; canvas margins drop to `margin-md` (1.5rem / 24px) with `gutter` (1rem / 16px). Multi-column metric blocks wrap into 2x2 grids.
- **Mobile Viewports (<768px):** Single-column stack with `margin` (1rem / 16px). Data tables switch to stacked card representations.
- **Spacing Application:**
  - `space-xs` (4px): Icon-to-label gaps, tight badge internal padding.
  - `space-sm` (8px): Form input padding, list item vertical spacing, table row compact gap.
  - `space-md` (12px): Component standard gap, button horizontal padding.
  - `space-lg` (16px): Standard card inner padding, filter bar spacing.
  - `space-xl` (24px): Card-to-card structural separation, module section breaks.

## Elevation & Depth

Visual hierarchy uses crisp boundary delineation rather than heavy shadows, ensuring optimal performance across enterprise web and embedded client consoles.

- **Level 0 (Base Canvas):** Background `#F4F6F9`, flat with zero elevation.
- **Level 1 (Card & Module Layer):** `#FFFFFF` surfaces bounded by a crisp 1px structural border (`#E2E8F0`) and an ambient, low-contrast shadow: `0px 1px 3px rgba(15, 23, 42, 0.05), 0px 1px 2px rgba(15, 23, 42, 0.03)`.
- **Level 2 (Hover & Active Surfaces):** Elevated interactive cards, flyouts, and active grid rows: `0px 4px 6px -1px rgba(15, 23, 42, 0.07), 0px 2px 4px -2px rgba(15, 23, 42, 0.04)` with a border shift to `#CBD5E1`.
- **Level 3 (Overlays & Menus):** Dropdowns, action popovers, and sticky filter bars: `0px 10px 15px -3px rgba(15, 23, 42, 0.08), 0px 4px 6px -4px rgba(15, 23, 42, 0.03)` with border `#E2E8F0`.
- **Level 4 (Modals & Critical Dialogs):** Diagnostic test modals, fleet reboot confirmation dialogs: `0px 20px 25px -5px rgba(15, 23, 42, 0.12), 0px 8px 10px -6px rgba(15, 23, 42, 0.04)` over a 40% opacity slate backdrop (`#0F172A66`).

## Shapes

The geometric architecture relies on controlled, restrained corner treatments (Soft / Scale 1) to convey rigorous industrial precision.

- **Small Controls (2px - 4px):** Checkboxes, radio inner indicators, and mini progress bars use `rounded-xs` (2px) to `rounded-sm` (4px).
- **Standard Controls (6px - 8px):** Form inputs, buttons, chips, table row containers, and tab segments use an exact 6px or 8px (`rounded-md`).
- **Cards & Data Modules (8px - 12px):** Metric widgets and operational cards use 8px (`rounded-md`) up to 12px (`rounded-lg`), reinforcing modern hardware industrial aesthetics.
- **Status Stepper & Badges (Fully Rounded / Pill):** Stepper nodes and semantic badge chips strictly utilize `rounded-full` (9999px) to contrast against rectangular data tables.

## Components

### Buttons & Actions
- **Primary:** Background `#0076CE`, text `#FFFFFF`, border none, 8px radius. Hover: `#005A9C`. Active: `#00487D`. Focused: 2px offset ring with `#0076CE`.
- **Secondary / Outline:** Background `#FFFFFF`, text `#0F172A`, 1px border `#CBD5E1`. Hover: `#F8FAFC` and border `#94A3B8`.
- **Destructive:** Background `#DC2626`, text `#FFFFFF`. Hover: `#B91C1C`.
- **Icon Action Buttons:** 32x32px square, subtle `#E2E8F0` border, `#475569` icon color; transitions to `#0076CE` background with `#FFFFFF` icon on active selection.

### Chips & Semantic Status Badges
- **Structure:** Pill-shaped (`rounded-full`), height 24px, horizontal padding 8px, font `label-sm` uppercase.
- **Critical Chip:** `#FEF2F2` background, `#DC2626` text, 1px border `#FCA5A5`, featuring an exclamation diamond or alert icon.
- **Warning Chip:** `#FFFBEB` background, `#D97706` text, 1px border `#FCD34D`, with caution triangle.
- **Passed / Normal Chip:** `#F0FDF4` background, `#16A34A` text, 1px border `#86EFAC`, with checkmark.
- **Info / In-Progress:** `#F0F9FF` background, `#0284C7` text, 1px border `#BAE6FD`, with sync or info dot.

### Diagnostic Cards & Metrics Widgets
- **Container:** Pure `#FFFFFF` surface, 8px or 12px corner radius, 1px `#E2E8F0` border, 16px internal padding.
- **Layout:** Header contains title (`headline-sm`) and contextual right-aligned status chip. Body contains key metric value (`display-lg`) above an interactive trend or progress bar. Footer provides a direct "Remediate" or "View Devices" action link.

### Interactive Stepper Pills
- Multi-step remediation and firmware update workflows use horizontal stepper tracks. Completed steps display `#16A34A` with checkmark icon; current step displays `#0076CE` with high-contrast numerical label; pending steps display `#E2E8F0` surface with `#64748B` neutral numbering.

### Data Tables & High-Density Lists
- **Header:** `#F8FAFC` background, height 36px, `label-sm` uppercase tracking with `#475569` text, sticky positioning, subtle 1px bottom border `#E2E8F0`.
- **Rows:** Height 44px (compact mode) or 52px (standard mode), hover background `#F1F5F9`. Bottom border 1px `#F1F5F9`.
- **Service Tag Column:** Uses `code-sm` font in `#0076CE` with hover underline for immediate single-click device drawer opening.

### Form Inputs & Filters
- **Text Inputs & Selects:** Height 36px, `#FFFFFF` background, 1px border `#CBD5E1`, 6px radius, placeholder in `#94A3B8`. Focus: border `#0076CE`, box-shadow `0 0 0 1px #0076CE`.
- **Checkboxes & Radios:** 16x16px, 4px corner radius for checkboxes, circular for radios. Inactive border `#94A3B8`. Active fill `#0076CE` with white glyph.